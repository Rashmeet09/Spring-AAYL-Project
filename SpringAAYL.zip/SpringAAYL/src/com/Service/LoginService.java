package com.Service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dao.LoginDAO;
import com.iNautix.Track;

@Service
public class LoginService {
	@Autowired
	LoginDAO dao;

	public boolean validate(String username, String password) throws SQLException {
		System.out.println("In Login Service 1");
		return dao.validate(username, password);
	}

	public List<Track> displayTrack() throws SQLException {
		System.out.println("In Login Service 2");
		return dao.displayTrack();
	}

	public int insert(String uname, String pword) {
		int i = 0;
		i = dao.insert(uname, pword);
		return i;
	}

	public List<String> getOption(String filter) {
		return dao.getOption(filter);
	}

	public List<Track> filter(String filter, String specific) {
		return dao.filter(filter, specific);
	}

	public boolean add(String title, String artist, String album, String genre) {
		return dao.add(title, artist, album, genre);
	}

	public boolean delete(String title) {
		return dao.delete(title);
	}
	
}
