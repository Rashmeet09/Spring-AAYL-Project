package com.iNautix;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class Eventmapper implements RowMapper<Track> {

            @Override
            public Track mapRow(ResultSet rs, int rownum) throws SQLException {
                        Track track=new Track();
                        track.setId(rs.getInt(1));
                        track.setTitle(rs.getString(2));
                        track.setArtist(rs.getString(3));
                        track.setAlbum(rs.getString(4));
                        track.setGenre(rs.getString(5));
                        return track;

            }	
} 

