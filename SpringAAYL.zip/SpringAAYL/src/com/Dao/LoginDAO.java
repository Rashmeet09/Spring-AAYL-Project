package com.Dao;

import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.iNautix.Eventmapper;
import com.iNautix.Track;

@Repository
public class LoginDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public boolean validate(String uname, String pword) throws SQLException {
		System.out.println("In Login Dao 1");
		String query = "select password from login_rash where username = ?";
		try {
			String password = (String) jdbcTemplate.queryForObject(query, String.class, uname);
			if (password.equals(pword)) {
				return true;
			}
		} catch (EmptyResultDataAccessException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	public List<Track> displayTrack() {
		System.out.println("In Login Dao 2");
		String query = "select * from trackinfo";
		List<Track> list = jdbcTemplate.query(query, new Eventmapper());
		return list;
	}

	public int insert(String uname, String pword) {
		String query = "insert into login_rash values(?,?)";
		int i = jdbcTemplate.update(query, uname, pword);
		return i;
	}

	public List<String> getOption(String filter) {
		String sql = null;
		if (filter.equals("artist")) {
			sql = "select distinct artist from trackinfo";
		} else if (filter.equals("album")) {
			sql = "select distinct album from trackinfo";
		} else if (filter.equals("genre")) {
			sql = "select distinct genre from trackinfo";
		}
		List<String> list = jdbcTemplate.queryForList(sql, String.class);
		return list;
	}

	public List<Track> filter(String filter, String specific) {
		String sql = null;
		if (filter.equals("artist")) {
			sql = "select * from trackinfo where artist=?";
		} else if (filter.equals("album")) {
			sql = "select * from trackinfo where album=?";
		} else if (filter.equals("genre")) {
			sql = "select * from trackinfo where genre=?";
		}
		List<Track> list1 = jdbcTemplate.query(sql, new Object[] { specific }, new Eventmapper());
		return list1;
	}

	public boolean add(String title, String artist, String album, String genre) {
		String temp = "select max(id) from trackinfo";
		int n = jdbcTemplate.queryForInt(temp);
		System.out.println("n:" + n);
		String sql = "insert into trackinfo values(?,?,?,?,?)";
		int i = jdbcTemplate.update(sql, n + 1, title, artist, album, genre);
		System.out.println("i:" + i);
		if (i == 1) {
			return true;
		}
		return false;
	}

	public boolean delete(String title) {
		String sql = "delete from trackinfo where title=?";
		int i = jdbcTemplate.update(sql, title);
		System.out.println("i:" + i);
		if (i > 0) {
			return true;
		}
		return false;
	}

}
