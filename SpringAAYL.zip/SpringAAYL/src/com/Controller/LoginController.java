package com.Controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.Service.LoginService;
import com.google.gson.Gson;
import com.iNautix.Track;

@Controller
public class LoginController {

	@Autowired
	private LoginService ls;

	@RequestMapping("/process1") // uri of request and http method
	public String printHello(Model model, @RequestParam("uname") String username,
			@RequestParam("pword") String password) throws SQLException {
		System.out.println("In Login Controller 1");
		boolean bool = ls.validate(username, password);
		if (bool) {
			System.out.print("Correct credentials!You have been Logged in!");
			List<Track> list = ls.displayTrack();
			model.addAttribute("list", list);
			return "Library";
		} else {
			System.out.print("Incorrect credentials!"); // do: print below only
			model.addAttribute("invalid", "Incorrect credentials");
			model.addAttribute("flag", "false");
			return "login";
		}
		// return "invalid";
	}

	@RequestMapping("/process2") // uri of request and http method
	public String ViewEvent(Model model, @RequestParam("uname") String username, @RequestParam("pword") String password)
			throws SQLException {
		System.out.println("In Login Controller 2");
		int i = ls.insert(username, password);
		if (i == 1) {
			System.out.println("Account created!");
			return "login";
		} else {
			System.out.println("Try creating account again!");
			return "Register";
		} // converted into responses
	}

	@ResponseBody
	@RequestMapping("/process3") // uri of request and http method
	public String getOption(String option1, Model model) throws SQLException {
		System.out.println("In Login Controller 3");
		System.out.println(option1);
		List<String> list = ls.getOption(option1);
		System.out.println(list);
		Gson gson = new Gson();
		String json = gson.toJson(list);
		// model.addAttribute("list",list);
		return json; // converted into responses
	}

	@ResponseBody
	@RequestMapping("/process4") // uri of request and http method
	public String search(String option1, String option2, Model model) throws SQLException {
		System.out.println("In Login Controller 4");
		System.out.println(option1 + option2);
		List<Track> list1 = ls.filter(option1, option2);
		System.out.println(list1);
		Gson gson = new Gson();
		String json1 = gson.toJson(list1);
		return json1;
	}

	@ResponseBody
	@RequestMapping("/process5") // uri of request and http method
	public String addition(String title, String artist, String album, String genre, Model model) throws SQLException {
		System.out.println("In Login Controller 5");
		System.out.println(title + artist + album + genre);
		boolean bool = ls.add(title, artist, album, genre);
		List<Track> list2 = null;
		if (bool) {
			list2 = ls.displayTrack();
		}
		System.out.println(list2);
		Gson gson = new Gson();
		String json2 = gson.toJson(list2);
		return json2;
	}

	@ResponseBody
	@RequestMapping("/process6") // uri of request and http method
	public String deletion(String title, String artist, String album, String genre, Model model) throws SQLException {
		System.out.println("In Login Controller 6");
		System.out.println(title);
		boolean bool = ls.delete(title);
		List<Track> list3 = null;
		if (bool) {
			list3 = ls.displayTrack();
		}
		System.out.println(list3);
		Gson gson = new Gson();
		String json3 = gson.toJson(list3);
		return json3;
	}

	@ResponseBody
	@RequestMapping("/process7") // get the title of songs
	public String title(Model model) throws SQLException {
		System.out.println("In Login Controller 7");
		List<Track> list4 = ls.displayTrack();
		System.out.println(list4);
		Gson gson = new Gson();
		String json4 = gson.toJson(list4);
		return json4;
	}

	@RequestMapping("/process8") // get the title of songs
	public String logout(HttpSession session) {
		System.out.println("In Login Controller 8");
		session.invalidate();
		return "login";
	}
}